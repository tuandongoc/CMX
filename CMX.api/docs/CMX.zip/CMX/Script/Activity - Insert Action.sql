/* Parameters :
	1 - EmployeeID
	2 - ActionID
	3 - EmployeeID
	4 - AccountID
	5 - AdditionalData
*/
INSERT INTO AccountActions VALUES(1,?,GETDATE(),?,GETDATE(),?,?,?,'0.00')