/* Parameters :
	1 - PromiseID
	2 - AccountID
	3 - EmployeeID
	4 - Sequence
	5 - AmountPromised
	6 - DatePromised
	7 - Term
	8 - Period
	9 - PeriodSeq
	10 - PromiseFrequency
	11 - PromiseGiver
*/

INSERT INTO AccountPromise VALUES(?,?,?,?,?,?,0,'1900-01-01 00:00:00',0.00,?,?,?,?,?,GETDATE(),NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
