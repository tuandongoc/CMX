/* Parameters :
	1 - AccountTicketID
	2 - AccountTicketActivityID
	3 - EmployeeID
	4 - Comment
*/

INSERT INTO CWX_AccountTicketActivityAction VALUES(?,-1,?,-1,-1,'Noted',?,GETDATE(),0,'Note','A'?)
