SELECT NoteID, E.EmployeeName, DebtorID, BillID, NoteDateTime, NoteType, NoteText, NotePriority
FROM NotesCurrent NC
LEFT JOIN Employee E ON NC.EmployeeID = E.EmployeeID
WHERE (NC.BillID = ? OR DebtorID = ?) AND
	NoteType = ? 
ORDER BY NoteDateTime DESC