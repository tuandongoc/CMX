/* Parameters :
	1 - ActionID
	2 - ActionType
	3 - EmployeeID
	4 - AccountID
*/
INSERT INTO AccountActionsOther VALUES(?,?,GETDATE(),?,?)