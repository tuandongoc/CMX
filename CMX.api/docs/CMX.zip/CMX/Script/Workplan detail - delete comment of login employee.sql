DELETE FROM CWX_AccountTicketActivityAction
WHERE TicketActivityActionID = ?