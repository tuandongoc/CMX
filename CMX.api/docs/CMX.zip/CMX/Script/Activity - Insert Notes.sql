/* Parameters :
	1 - EmployeeID
	2 - DebtorID
	3 - AccountID
	4 - NoteType
	5 - NoteText
	6 - NotePriority
*/

INSERT INTO NotesCurrent VALUES(?,?,?,GETDATE(),?,?,?,NULL)